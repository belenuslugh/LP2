﻿namespace PtesteMetades
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.bntNumeros = new System.Windows.Forms.Button();
            this.bntBranco = new System.Windows.Forms.Button();
            this.bntLetras = new System.Windows.Forms.Button();
            this.bntLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchtxtFrase.Location = new System.Drawing.Point(149, 46);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(438, 137);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // bntNumeros
            // 
            this.bntNumeros.BackColor = System.Drawing.Color.White;
            this.bntNumeros.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntNumeros.Location = new System.Drawing.Point(149, 198);
            this.bntNumeros.Name = "bntNumeros";
            this.bntNumeros.Size = new System.Drawing.Size(438, 46);
            this.bntNumeros.TabIndex = 1;
            this.bntNumeros.Text = "Contas Números";
            this.bntNumeros.UseVisualStyleBackColor = false;
            this.bntNumeros.Click += new System.EventHandler(this.bntNumeros_Click);
            // 
            // bntBranco
            // 
            this.bntBranco.BackColor = System.Drawing.Color.White;
            this.bntBranco.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntBranco.Location = new System.Drawing.Point(149, 250);
            this.bntBranco.Name = "bntBranco";
            this.bntBranco.Size = new System.Drawing.Size(438, 47);
            this.bntBranco.TabIndex = 2;
            this.bntBranco.Text = "Posição 1° caracter branco";
            this.bntBranco.UseVisualStyleBackColor = false;
            this.bntBranco.Click += new System.EventHandler(this.bntBranco_Click);
            // 
            // bntLetras
            // 
            this.bntLetras.BackColor = System.Drawing.Color.White;
            this.bntLetras.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntLetras.Location = new System.Drawing.Point(149, 303);
            this.bntLetras.Name = "bntLetras";
            this.bntLetras.Size = new System.Drawing.Size(438, 39);
            this.bntLetras.TabIndex = 3;
            this.bntLetras.Text = "Conta Letras";
            this.bntLetras.UseVisualStyleBackColor = false;
            this.bntLetras.Click += new System.EventHandler(this.bntLetras_Click);
            // 
            // bntLimpar
            // 
            this.bntLimpar.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntLimpar.Location = new System.Drawing.Point(189, 348);
            this.bntLimpar.Name = "bntLimpar";
            this.bntLimpar.Size = new System.Drawing.Size(354, 41);
            this.bntLimpar.TabIndex = 10;
            this.bntLimpar.Text = "Limpar";
            this.bntLimpar.UseVisualStyleBackColor = true;
            this.bntLimpar.Click += new System.EventHandler(this.bntLimpar_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Moccasin;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bntLimpar);
            this.Controls.Add(this.bntLetras);
            this.Controls.Add(this.bntBranco);
            this.Controls.Add(this.bntNumeros);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.Load += new System.EventHandler(this.frmExercicio4_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button bntNumeros;
        private System.Windows.Forms.Button bntBranco;
        private System.Windows.Forms.Button bntLetras;
        private System.Windows.Forms.Button bntLimpar;
    }
}