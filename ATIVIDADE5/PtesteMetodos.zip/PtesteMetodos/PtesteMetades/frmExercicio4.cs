﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetades
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void bntNumeros_Click(object sender, EventArgs e)
        {
            int contador = 0, contNum = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador])) contNum++;

                contador++;
            }
            MessageBox.Show($"Foram encontrados {contNum} números no texto.");
        }

        private void bntBranco_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text;
            int naoTem = 0;

             for (int localizador = 0; localizador < rchtxtFrase.Text.Length ; localizador++)
             {
                if (Char.IsWhiteSpace(frase, localizador))
                {
                    MessageBox.Show($"O primeiro espaço em branco está na posição {localizador + 1}.");
                    naoTem++;
                    break;

                }      

             }
             if (naoTem == 0)
             {
               MessageBox.Show("Não há espaços em branco no texto.");
             }
            
        }

        private void bntLetras_Click(object sender, EventArgs e)
        {
            int caracteres = 0;
           foreach (char c in rchtxtFrase.Text)
           {
                if (Char.IsLetter(c))
                {
                    caracteres ++;
                }
           }
            MessageBox.Show($"Foram encontrados {caracteres} caracteres alfabéticos no texto.");
        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            rchtxtFrase.Clear();
        }
    }
}
