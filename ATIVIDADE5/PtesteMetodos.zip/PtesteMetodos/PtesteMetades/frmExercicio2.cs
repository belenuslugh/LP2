﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetades
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
           
        }

        private void frmExercicio2_Load(object sender, EventArgs e)
        {

        }

        private void bntInserir_Click(object sender, EventArgs e)
        {
            int metade = txtPalavra2.Text.Length / 2;
            
            txtPalavra2.Text = txtPalavra2.Text.Substring(0, metade) + txtPalavra1.Text + txtPalavra2.Text.Substring(metade, txtPalavra2.TextLength - metade);

        }

        private void bntInserir2_Click(object sender, EventArgs e)
        {
            int metade = txtPalavra1.Text.Length / 2;
            txtPalavra2.Text = txtPalavra1.Text.Insert(metade, "**");
        }

        private void bntIguais_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text, palavra2 = txtPalavra2.Text;
            if (String.Compare(palavra1, palavra2, true) == 0)
                MessageBox.Show("Os textos são idênticos!");
            else
                MessageBox.Show("Os textos são diferentes!");
        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            txtPalavra1.Clear();
            txtPalavra2.Clear();
        }
    }
}
