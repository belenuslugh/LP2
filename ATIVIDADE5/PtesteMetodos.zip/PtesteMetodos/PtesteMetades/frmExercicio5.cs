﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetades
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void frmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void bntSorteio_Click(object sender, EventArgs e)
        {
            int num1 , num2;

            if(!int.TryParse(txtNumero1.Text,out num1) || ! int.TryParse(txtNumero2.Text,out num2) || (num2 < num1 ))
            {
                MessageBox.Show("Os valores informados são inválidos");
                txtNumero1.Focus();
            }
            else
            {
                Random obj5= new Random();
                int sorteado = obj5.Next(num1, num2);
                MessageBox.Show($"Número sorteado: {sorteado}");
            }
        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            
        }

        private void bntLimpar_Click_1(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
        }
    }
}
