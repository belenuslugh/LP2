﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace At7.Eduardo.F.P
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnNumeroR_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text.Trim();
            int totalR = 0;
            int contador = 0;
            do
            {
                if (Char.ToUpper(frase[contador]) == 'R')
                {
                    totalR += 1;
                }
                contador += 1;
            }
            while (contador < frase.Length);
            MessageBox.Show( "O texto  tem " + totalR.ToString() + " letra(s) R");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text.Replace(" ", "");
            int paresLetras = 0;

            for (int i = 0; i < (frase.Length - 1); i++) 
            {
        
                if (Char.ToUpper(frase[i]) == Char.ToUpper(frase[i+1]))
                { 
                    paresLetras += 1;
                    i++;
                }
            }
            MessageBox.Show("O número de par de letras na frase são: " + paresLetras.ToString() );
        }

        private void txtFrase_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEspacosBranco_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text;
            int numBranco = 0 ;
            int i = 0;
            while (frase.Length > i) {
                if (Char.IsWhiteSpace(frase[i])){
                    numBranco++;
                }
                i++;
            }
            MessageBox.Show("O número de espaços em branco é: " + numBranco.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtFrase.Text = "";
        }
    }
}
