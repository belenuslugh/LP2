﻿namespace At7.Eduardo.F.P
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.frmExercicio1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmExercicio2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmExercicio3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmExercicio4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.frmExercicio1ToolStripMenuItem,
            this.frmExercicio2ToolStripMenuItem,
            this.frmExercicio3ToolStripMenuItem,
            this.frmExercicio4ToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // frmExercicio1ToolStripMenuItem
            // 
            this.frmExercicio1ToolStripMenuItem.Name = "frmExercicio1ToolStripMenuItem";
            this.frmExercicio1ToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.frmExercicio1ToolStripMenuItem.Text = "frmExercicio1";
            this.frmExercicio1ToolStripMenuItem.Click += new System.EventHandler(this.frmExercicio1ToolStripMenuItem_Click);
            // 
            // frmExercicio2ToolStripMenuItem
            // 
            this.frmExercicio2ToolStripMenuItem.Name = "frmExercicio2ToolStripMenuItem";
            this.frmExercicio2ToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.frmExercicio2ToolStripMenuItem.Text = "frmExercicio2";
            this.frmExercicio2ToolStripMenuItem.Click += new System.EventHandler(this.frmExercicio2ToolStripMenuItem_Click);
            // 
            // frmExercicio3ToolStripMenuItem
            // 
            this.frmExercicio3ToolStripMenuItem.Name = "frmExercicio3ToolStripMenuItem";
            this.frmExercicio3ToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.frmExercicio3ToolStripMenuItem.Text = "frmExercicio3";
            this.frmExercicio3ToolStripMenuItem.Click += new System.EventHandler(this.frmExercicio3ToolStripMenuItem_Click);
            // 
            // frmExercicio4ToolStripMenuItem
            // 
            this.frmExercicio4ToolStripMenuItem.Name = "frmExercicio4ToolStripMenuItem";
            this.frmExercicio4ToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.frmExercicio4ToolStripMenuItem.Text = "frmExercicio4";
            this.frmExercicio4ToolStripMenuItem.Click += new System.EventHandler(this.frmExercicio4ToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem frmExercicio1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmExercicio2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmExercicio3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmExercicio4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
    }
}

