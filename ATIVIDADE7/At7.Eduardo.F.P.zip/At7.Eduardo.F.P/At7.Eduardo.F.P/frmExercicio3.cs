﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace At7.Eduardo.F.P
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnIdentificar_Click(object sender, EventArgs e)
        {
            string texto = txtPalindromo.Text.Replace(" ", "");
            string textoMinusculos = texto.ToLower();

            char[]  Invertido = textoMinusculos.ToCharArray(); ;
            Array.Reverse(Invertido);
            string textoInvertido = new string(Invertido);

            if (String.Compare(textoMinusculos, textoInvertido, true) == 0)
            {
                MessageBox.Show($"O texto é um palíndromo");
            }
            else
            {
                MessageBox.Show($"O texto não é um palíndromo");
            }


            /*  
             *  OU
             *  
            string texto = txtPalindromo.Text.Replace(" ", "");
            int fim = texto.Length -1;
            bool difarente = true;
            for (int i = 0; i < texto.Length/2; i++)
            {
                if (Char.ToUpper(texto[i]) != Char.ToUpper(texto[fim]))
                {
                    difarente = false;
                    MessageBox.Show($"Os não é um Palindromo ");
                    break;
                }
                fim--;
            }
            if (difarente) {
                MessageBox.Show($"Os é um Palindromo ");
            
            }*/

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtPalindromo.Clear();
        }
    }
}
