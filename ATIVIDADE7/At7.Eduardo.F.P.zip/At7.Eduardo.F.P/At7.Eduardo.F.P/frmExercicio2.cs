﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace At7.Eduardo.F.P
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnGerarNumero_Click(object sender, EventArgs e)
        {

            double N, H = 0;
            if (!double.TryParse(txtoNumeroN.Text, out N) || N < 0)
            {
                MessageBox.Show("Os valores informados esta inválidos");
                txtoNumeroN.Focus();
            }
            else
            {
                for (double i = 1; i <= N; i++) {
                    H += 1 / i;
                }
                MessageBox.Show($" O seu numero Gerado é {H} ");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtoNumeroN.Clear();
        }
    }
}
