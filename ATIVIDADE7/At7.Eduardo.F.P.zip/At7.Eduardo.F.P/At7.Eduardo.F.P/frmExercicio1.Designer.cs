﻿namespace At7.Eduardo.F.P
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEspacosBranco = new System.Windows.Forms.Button();
            this.btnNumeroR = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtFrase = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEspacosBranco
            // 
            this.btnEspacosBranco.BackColor = System.Drawing.Color.White;
            this.btnEspacosBranco.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F);
            this.btnEspacosBranco.Location = new System.Drawing.Point(226, 192);
            this.btnEspacosBranco.Name = "btnEspacosBranco";
            this.btnEspacosBranco.Size = new System.Drawing.Size(324, 45);
            this.btnEspacosBranco.TabIndex = 1;
            this.btnEspacosBranco.Text = "Número de espaços em branco";
            this.btnEspacosBranco.UseVisualStyleBackColor = false;
            this.btnEspacosBranco.Click += new System.EventHandler(this.btnEspacosBranco_Click);
            // 
            // btnNumeroR
            // 
            this.btnNumeroR.BackColor = System.Drawing.Color.White;
            this.btnNumeroR.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumeroR.Location = new System.Drawing.Point(226, 243);
            this.btnNumeroR.Name = "btnNumeroR";
            this.btnNumeroR.Size = new System.Drawing.Size(324, 45);
            this.btnNumeroR.TabIndex = 2;
            this.btnNumeroR.Text = "O número de vezes que aparece a letra “R\"";
            this.btnNumeroR.UseVisualStyleBackColor = false;
            this.btnNumeroR.Click += new System.EventHandler(this.btnNumeroR_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F);
            this.button3.Location = new System.Drawing.Point(226, 294);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(324, 45);
            this.button3.TabIndex = 3;
            this.button3.Text = "O número mesmo par de letras ";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtFrase
            // 
            this.txtFrase.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F);
            this.txtFrase.Location = new System.Drawing.Point(226, 87);
            this.txtFrase.MaxLength = 100;
            this.txtFrase.Name = "txtFrase";
            this.txtFrase.Size = new System.Drawing.Size(324, 99);
            this.txtFrase.TabIndex = 4;
            this.txtFrase.Text = "";
            this.txtFrase.TextChanged += new System.EventHandler(this.txtFrase_TextChanged);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F);
            this.button1.Location = new System.Drawing.Point(328, 345);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 39);
            this.button1.TabIndex = 5;
            this.button1.Text = "Limpar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtFrase);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnNumeroR);
            this.Controls.Add(this.btnEspacosBranco);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnEspacosBranco;
        private System.Windows.Forms.Button btnNumeroR;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RichTextBox txtFrase;
        private System.Windows.Forms.Button button1;
    }
}