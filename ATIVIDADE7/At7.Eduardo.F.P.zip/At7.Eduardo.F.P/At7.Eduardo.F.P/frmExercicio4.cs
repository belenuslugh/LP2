﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace At7.Eduardo.F.P
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnEspacosBranco_Click(object sender, EventArgs e)
        {
            int b = 0, c = 0, d = 0;
          
            double producao, gratificacao, salario, salarioBruto;
            if (!double.TryParse(txtProducao.Text, out producao) || producao < 0)
            {
                MessageBox.Show("Os valores informados na Produção são inválidos");
                txtProducao.Focus();
            }
            else
            {
                if (!double.TryParse(txtGratificacao.Text, out gratificacao) || gratificacao < 0)
                {
                    MessageBox.Show("Os valores informados na Gratificação são inválidos");
                    txtGratificacao.Focus();
                }
                else
                {
                    if (!double.TryParse(txtSalario.Text, out salario) || salario <= 0)
                    {
                        MessageBox.Show("Os valores informados na Salário são inválidos");
                        txtSalario.Focus();
                    }
                    else {
                        b = producao >= 100 ? 1 : 0;
                        c = producao >= 120 ? 1 : 0;
                        d = producao >= 150 ? 1 : 0;

                        salarioBruto = salario + salario * (0.05*b + 0.1 * c + 0.1 * d) + gratificacao;

                        if (salarioBruto > 7000 && (d == 0 ||  gratificacao == 0) )
                        {
                            salarioBruto = 7000;
                        }
                        MessageBox.Show($"O salário bruto calculado é: {salarioBruto} ");
                        
                    }
                }


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtSalario.Clear();
            txtGratificacao.Clear();
            txtProducao.Clear();
            txtNome.Clear();
            txtMatricula.Clear();
        }
    }
}
