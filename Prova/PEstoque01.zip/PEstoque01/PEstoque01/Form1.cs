﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PEstoque01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int [,] estoque = new int [2,4];
            string auxiliar;

            int produtosMes = 0 , entradasGeral = 0;



            for (int mes = 0; mes < 2; mes++)
            {
                for (int semana = 0; semana < 4; semana++)
                {
                    auxiliar = Interaction.InputBox($"Digite numero de Produto da Semana {semana + 1}° no mes{mes + 1}°", "Entrada de Dados");
                    if ((int.TryParse(auxiliar, out estoque[mes, semana])) && estoque[mes, semana] >= 0)
                    {
                        produtosMes += estoque[mes, semana];
                        listBoxEstoque.Items.Add($"Total Entradas do Produto:{mes + 1}°  Semana {semana + 1}° --{estoque[mes, semana]}");

                    }
                    else
                    {
                        MessageBox.Show($"Entrada inválida! Digite Dados interio para o mes {mes + 1}, Semana {semana + 1}.", "Erro");
                        semana--;
                    }

                }
                listBoxEstoque.Items.Add($">>Total do Entrada  do Produto {mes + 1}°         {produtosMes}");
                listBoxEstoque.Items.Add("................................................................");
                entradasGeral += produtosMes;
                produtosMes = 0;
            }
            listBoxEstoque.Items.Add($">>Total do Geral Entradas                     {entradasGeral}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBoxEstoque.Items.Clear();
        }
    }
}
