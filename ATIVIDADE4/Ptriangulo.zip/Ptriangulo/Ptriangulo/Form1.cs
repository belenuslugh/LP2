﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxLadoA.Clear();
            mskbxLadoB.Clear();
            mskbxLadoC.Clear();
            mskbkTipo.Clear();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxLadoA.Text, out ladoA) || 0 >= ladoA ){

                MessageBox.Show("Por favor, insira um valor válido para o Lado A.");
                mskbxLadoA.Focus();
            }
            else
            {
                if (!double.TryParse(mskbxLadoB.Text, out ladoB) || 0 >= ladoB) {
                    MessageBox.Show("Por favor, insira um valor válido para o Lado B.");
                    mskbxLadoB.Focus();
                }
                else
                {
                    if (!double.TryParse(mskbxLadoC.Text, out ladoC) || 0 >= ladoC)
                    {
                        MessageBox.Show("Por favor, insira um valor válido para o Lado C.");
                        mskbxLadoC.Focus();
                    }
                    else
                    {
                        if (ladoA + ladoB > ladoC && ladoA + ladoC > ladoB && ladoB + ladoC > ladoA)
                        {

                            if (ladoC == ladoB && ladoA == ladoC)
                            {
                                mskbkTipo.Text = "Triângulo Equilátero";
                            }
                            else
                            {
                                if ((ladoA == ladoB && ladoB != ladoC) || (ladoB == ladoC && ladoA != ladoC) || (ladoA == ladoC && ladoB != ladoC))
                                {
                                    mskbkTipo.Text = "Triângulo Isósceles";
                                }
                                else
                                {
                                    if (ladoA != ladoB && ladoB != ladoC && ladoA != ladoC)
                                    {
                                        mskbkTipo.Text = "Triângulo Escaleno";
                                    }
                                }
                            }
                        }
                        else {
                            MessageBox.Show("Os lados informados não podem formar um triângulo");
                        }
                    }

                }
            }
        }
            
        
    }
}
