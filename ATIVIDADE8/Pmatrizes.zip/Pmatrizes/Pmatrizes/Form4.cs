﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnNomes_Click(object sender, EventArgs e)
        {
            string[] vetor = new string[10];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o Nome {i + 1}°", "Entrada de Dados");
                if (auxiliar == "")
                {
                    break;
                }
                vetor[i] = auxiliar.Replace(" ","");
                listBoxComprimento.Items.Add(auxiliar + ",  comprimento : " + vetor[i].Length);
            }
          
        }
    }
}
