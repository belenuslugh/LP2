﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int [] vetor = new int [20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o número {i+1}°", "Entrada de Dados");
                if(auxiliar == "")
                {
                    break;
                } 
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show($"número inválido! {i+1}°");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach(int j in vetor)
            {
                auxiliar += j + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList();
            lista.Add("ana");
            lista.Add("André ");
            lista.Add("Beatriz");
            lista.Add(" Camila João");
            lista.Add("Joana");
            lista.Add("Otávio");
            lista.Add("Marcelo");
            lista.Add("Pedro");
            lista.Add("Thais");

            lista.Remove("Otávio");

            string resultado = string.Join("\n", lista.ToArray());
            MessageBox.Show(resultado);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            string auxiliar, resultado = "";
            double[,] disciplina = new double[20,3];
            double[] media = new double[20];
 
            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite o nota  {nota + 1}° do aluno {aluno + 1}°", "Entrada de Dados");

                    if (!double.TryParse(auxiliar, out disciplina[aluno, nota]) || disciplina[aluno, nota] < 0 || disciplina[aluno, nota] > 10)
                    {
                        MessageBox.Show($"número inválido!  {nota + 1}° do aluno {aluno + 1}°");
                        nota--;
                    }
                    else { 
                        media[aluno] += disciplina[aluno, nota];
                    }
                }
                //media[aluno] = media[aluno] / 3;
                resultado += $"Aluno {aluno + 1}° : média:{media[aluno] / 3} \n";
            }
            MessageBox.Show(resultado);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {            
                Form4 obj2 = new Form4();
                obj2.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            Form5 obj2 = new Form5();
            obj2.Show();
        }
    }
}
